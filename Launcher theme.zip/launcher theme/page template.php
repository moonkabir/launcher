<?php
/**
 * Template Name: Launcher Homepage2
 */
get_header();
?>

<h1>
	<?php the_title(); ?>
</h1>

<?php get_footer(); ?>