<!DOCTYPE HTML>
<!--
	Launcher by freehtml5.co
	Twitter: http://twitter.com/fh5co
	URL: http://freehtml5.co
-->
<html>
<head>
    <meta charset="utf-8">
    <?php wp_head();?>

</head>